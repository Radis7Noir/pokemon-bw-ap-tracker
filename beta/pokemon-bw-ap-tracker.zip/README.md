# Pokémon Black \& White Tracker for Archipelago

## Features (for v0.3.14 of the apworld and later)

* Key Items Tracking
* Item Locations Tracking
* Event Tracking
* Auto-Tabbing
* Split Mode
* Hint Highlighting
* Settings Display for most settings
  * You can manually hide some of the commonly excluded locations in the Location Visibility section of the settings pop-up
* Encounters Tracking
  * You can decide whether to show all Pokémon and track them automatically or to only show encounters which are Dexsanity checks
* Evolution Logic Display
* Pokésearch

## Split Mode
This tool allows you to either display one singular map at a time or the overworld map and a submap at the same time. Click on the `SPLT` icon to change the tracker to the following modes:
- `Split Map - OFF`: The tracker only displays one tab.
- `Split Map - ON`: The tracker displays the submaps on the left and the Overworld/Pokédex tabs on the right.
- `Split Map - Reverse`: The tracker displays the Overworld/Pokédex tabs on the left and the submaps on the right.

## Auto-Tabbing
When enabled, the tracker will change the displayed map to match the state of the game. With `Split Map - ON` and `Split Map - Reverse`, only the submap tab will be switched. Click on the `AUTO` icon located in the Tools grid to turn on/off auto-tabbing. 

## Hint Tracking
This pack features a hint tracking system with three different modes: `ON`, `Advanced` and `OFF`. You can change the mode in the Tools grid by clicking on the `HINT` icon.
- `ON`: Hinted locations will appear on the overworld map and the submaps with a colored glow that corresponds to the priority of the items they hold.
- `Advanced`: Hinted progression locations will appear on the overworld map and the submaps with a golden glow. Other hinted items will be marked as cleared.
- `OFF`: Turns off the hint tracking feature.

## Pokésearch
While connected to a slot, you can search for a specific Pokémon by entering its Pokédex ID and clicking on the Enter button. You can find a list of all IDs [here](https://bulbapedia.bulbagarden.net/wiki/List_of_Pok%C3%A9mon_by_National_Pok%C3%A9dex_number). When performing a search, the map settings will change to only show the encounter slots that contain the searched Pokémon. Adjust the Encounter Tracking and Locations options in the Tools grid to cancel a search.
Some useful IDs:
- `585` (Deerling)
- `251` (Celebi)
- `546` (Cottonee)
- `548` (Petilil)
- `572, 573` (Minccino, Cinccino)
- `525` (Boldore)
- `243, 244, 245` (Raikou, Entei, Suicune)
- `132` (Ditto)
- `641, 642` (Tornadus, Thundurus)

## Seen Species Logic
The following locations will turn blue as soon as you can physically access them. They will turn green once you have seen enough species to complete them. The tracker cannot know exactly when there are enough species in the world to be seen. Use Universal Tracker to find out if the locations are currently accessible.

```
    - "Castelia City - Item from scientist in building in northern street"
    - "Driftveil City - Item from man for seeing more than 50 pokémon"
    - "Nuvema Town - TM from Professor Juniper for seeing 115 species"
    - "Nuvema Town - TM from Professor Juniper for seeing 25 species"
    - "Nuvema Town - TM from Professor Juniper for seeing 60 species"
```

## Deerling Forms Logic
Due to PopTracker limitations, the logic for `Route 6 - Item from scientist for all Deerling forms` can't exactly reflect the apworld's. In PopTracker, the location will turn blue when it becomes physically reachable and remain blue until it is cleared. Use Universal Tracker to find out if the location is currently accessible and use Pokésearch or the in-game Pokédex to check Deerling's locations.
 
## Location Visibility Lists
You can manually show or hide the following groups of locations by clicking on their corresponding icon in the settings pop-up. You should only consider hiding a location if you excluded it in your YAML.

- Show/Hide Abyssal Ruins Locations (46 locations)
```
    - "Abyssal Ruins items"
```
- Show/Hide Pokédex Appraisal Locations (6 locations)
```
    - "Castelia City - Item from scientist in building in northern street"
    - "Driftveil City - Item from man for seeing more than 50 pokémon"
    - "Nuvema Town - TM from Professor Juniper for seeing 115 species"
    - "Nuvema Town - TM from Professor Juniper for seeing 25 species"
    - "Nuvema Town - TM from Professor Juniper for seeing 60 species"
    - "Route 6 - Item from scientist for all Deerling forms"
```
- Show/Hide Breeders and Rangers Locations (24 locations)
```
    - "Desert Resort - Item from ranger Jaden"
    - "Desert Resort - Item from ranger Mylene"
    - "Moor of Icirrus - Item from ranger Chloris"
    - "Moor of Icirrus - Item from ranger Harry"
    - "Pinwheel Forest - Item from ranger Audra"
    - "Pinwheel Forest - Item from ranger Forrest"
    - "Pinwheel Forest - Item from ranger Irene"
    - "Pinwheel Forest - Item from ranger Miguel"
    - "Route 1 - Item from ranger Brenda"
    - "Route 1 - Item from ranger Claude"
    - "Route 11 - Item from ranger Crofton"
    - "Route 11 - Item from ranger Thalia"
    - "Route 12 - Item from breeder Ethel"
    - "Route 12 - Item from breeder Eustace"
    - "Route 15 - Item from ranger Keith"
    - "Route 15 - Item from ranger Shelly"
    - "Route 3 - Item from pokémon breeder Adelaide"
    - "Route 3 - Item from pokémon breeder Galen"
    - "Route 6 - Item from ranger Richard"
    - "Route 6 - Item from ranger Shanti"
    - "Route 7 - Item from ranger Mary"
    - "Route 7 - Item from ranger Pedro"
    - "Route 8 - Item from ranger Annie"
    - "Route 8 - Item from ranger Lewis"
```
- Show/Hide Winter or All Season Items Locations (12-17 locations)
```
-- Winter Locations
    - "Dragonspiral Tower - Item near entrance (Winter)"
    - "Icirrus City - Hidden item west of pokémon center (Winter)"
    - "Icirrus City - Item from the former Team Rocket member's wife (Winter)"
    - "Icirrus City - Item west of pokémon center (Winter)"
    - "Icirrus City - South hidden item #1 (Winter)"
    - "Icirrus City - South hidden item #2 (Winter)"
    - "Icirrus City - South hidden item #3 (Winter)"
    - "Twist Mountain - Lower floor little east cave item (Winter)"
    - "Twist Mountain - Main floor east hidden item (Winter)"
    - "Twist Mountain - Main floor north hidden item #1 (Winter)"
    - "Twist Mountain - Main floor north hidden item #2 (Winter)"
    - "Twist Mountain - Middle floor north cave item (Winter)"

-- Spring/Summer/Autumn Locations
    - "Moor of Icirrus - Hidden item behind boulder (Spring/Summer/Autumn)"
    - "Moor of Icirrus - South east item (Spring/Summer/Autumn)"
    - "Route 8 - West hidden item (Spring/Summer/Autumn)"
    - "Twist Mountain - Lower floor north west cave hidden item (Spring/Summer/Autumn)"
    - "Twist Mountain - Lower floor north west cave item (Spring/Summer/Autumn)"
```
