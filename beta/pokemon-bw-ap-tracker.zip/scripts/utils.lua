function has(item, amount)
    local count = Tracker:ProviderCountForCode(item)
    amount = tonumber(amount)
    if not amount then
        return count > 0
    else
        return count >= amount
    end
end


function dump_table(o, depth)
    if depth == nil then
        depth = 0
    end

    local ignore_keys = {

    }

    if type(o) == 'table' then
        local tabs = ('\t'):rep(depth)
        local tabs2 = ('\t'):rep(depth + 1)
        local s = '{\n'
        for k, v in pairs(o) do
            local key_str = tostring(k)
            if not ignore_keys[key_str] then
                if type(k) ~= 'number' then
                    k = '"' .. k .. '"'
                end
                s = s .. tabs2 .. '[' .. k .. '] = ' .. dump_table(v, depth + 1) .. ',\n'
            end
        end
        return s .. tabs .. '}'
    else
        return tostring(o)
    end
end

function table_contains(table, element)
    for _, value in pairs(table) do
        if value == element then
            return true
        end
    end
    return false
end

function toggle_versionmaps()
    if has("pokemon_black") then
        Tracker:AddMaps("maps/version.json")
    elseif has("pokemon_white") then
        Tracker:AddMaps("maps/version_w.json")
	end
    local formsanity = Tracker:FindObjectForCode("formsanity").AcquiredCount
    local shinyformsanity = Tracker:FindObjectForCode("shinyformsanity").AcquiredCount
    if formsanity > 0  or shinyformsanity > 0 then
        Tracker:AddLayouts("layouts/pokedex_form.json")
    else
        Tracker:AddLayouts("layouts/pokedex.json")
    end
end

function toggle_keyitemgrid()    
    local suffix = ""
    if has("pokemon_white") then
        suffix = suffix .. "_w"
	end

    if has("dynamic_version") then
        suffix = suffix .. "_dynamic"
    end

    Tracker:AddLayouts("layouts/items/items"..suffix..".json")
end

function toggle_goal()
    local suffix = ""
    if has("pokemon_white") then
        suffix = suffix .. "_w"
	end

    if has("goal_champion_on") then
        suffix = suffix .. "_champion"
	end

    if has("goal_cynthia_on") then
        suffix = suffix .. "_cynthia"
	end

    if has("goal_tmhm_hunt_on") then
        suffix = suffix .. "_tmhmhunt"
	end

    if has("goal_seven_sages_hunt_on") then
        suffix = suffix .. "_sevensageshunt"
	end

    if has("goal_legendary_hunt_on") then
        suffix = suffix .. "_legendaryhunt"
	end

	Tracker:AddLayouts("layouts/events/events"..suffix..".json")
end

function toggle_seasongrid()   
    local suffix = ""
    if has("season_control_randomized") then
        suffix = suffix .. "_seasons"
    end
	
    Tracker:AddLayouts("layouts/tracker"..suffix..".json")
end

function toggle_splitmap()
    if has("splitmap_off") then
        Tracker:AddLayouts("layouts/tabs_single.json")
    elseif has("splitmap_on") then
        Tracker:AddLayouts("layouts/tabs_split.json")
    elseif has("splitmap_reverse") then
        Tracker:AddLayouts("layouts/tabs_reverse.json")
    end
end

-- only swap when it changes, re-adding every time lags
DEXSEARCH_FORM_LAYOUT = "layouts/dexsearch/dexsearch_form.json"

function toggle_dexsearch_form()
    local dex = getDigits("dexsearch_digit1", "dexsearch_digit2", "dexsearch_digit3")
    local layout = "layouts/dexsearch/dexsearch_form.json"
    if Tracker:FindObjectForCode("dexsearch_form_" .. dex) then
        layout = "layouts/dexsearch/dexsearch_form_" .. dex .. ".json"
    end
    if layout ~= DEXSEARCH_FORM_LAYOUT then
        DEXSEARCH_FORM_LAYOUT = layout
        Tracker:AddLayouts(layout)
    end
end

function getDigits(code1, code2, code3)
    return (Tracker:FindObjectForCode(code1).CurrentStage or 0) * 100
         + (Tracker:FindObjectForCode(code2).CurrentStage or 0) * 10
         + (Tracker:FindObjectForCode(code3).CurrentStage or 0)
end

function syncHostedFromBase(code)
    Tracker:FindObjectForCode(code.."_hosted").Active = Tracker:FindObjectForCode(code).Active
end

function syncBaseFromHosted(code)
    local base = code:gsub("_hosted", "")
    Tracker:FindObjectForCode(base).Active = Tracker:FindObjectForCode(code).Active
end