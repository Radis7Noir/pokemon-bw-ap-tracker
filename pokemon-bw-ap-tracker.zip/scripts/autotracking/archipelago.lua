ScriptHost:LoadScript("scripts/autotracking/item_mapping.lua")
ScriptHost:LoadScript("scripts/autotracking/location_mapping.lua")
ScriptHost:LoadScript("scripts/autotracking/encounter_mapping.lua")
ScriptHost:LoadScript("scripts/autotracking/flag_mapping.lua")
ScriptHost:LoadScript("scripts/autotracking/map_mapping.lua")
ScriptHost:LoadScript("scripts/autotracking/option_mapping.lua")

REGION_ENCOUNTERS = {}
CUR_INDEX = -1
PLAYER_ID = -1
TEAM_NUMBER = 0
SLOT_DATA = nil
LOCAL_ITEMS = {}
GLOBAL_ITEMS = {}
HINT_ID = {}
EVENT_BITS = {}
MAP_ID = {}

if Highlight then
    HIGHLIGHT_LEVEL= {
        [10] = Highlight.Unspecified,
        [20] = Highlight.Avoid,
        [30] = Highlight.Priority,
        [40] = Highlight.None,
        [100] = Highlight.Unspecified,
        [101] = Highlight.Priority,
        [102] = Highlight.NoPriority,
        [103] = Highlight.Priority,
        [104] = Highlight.Avoid,
        [105] = Highlight.Priority,
        [106] = Highlight.NoPriority,
        [107] = Highlight.Priority,
    }
end

HIGHLIGHT_PRIORITY =  {
    [Highlight.Priority] = 1, -- priority
    [Highlight.NoPriority] = 2, -- useful
    [Highlight.Avoid] = 3, -- trap
    [Highlight.Unspecified] = 4, -- filler
    [Highlight.None] = 5 -- none
}

function applyCodes(tbl) -- helper for slot data processing. we can't do a clean mapping like Pt because some slot data are nested and some are not, plus tables everywhere :D
    for k, v in pairs(tbl) do
        if SLOT_CODES[k] then
            local stage = (SLOT_CODES[k].mapping and SLOT_CODES[k].mapping[v] or v)
            Tracker:FindObjectForCode(SLOT_CODES[k].code).CurrentStage = stage
        elseif LIST_CODES[k] then
            local list = type(v) == "table" and v or { v } -- solo goal is string, combined is table ,so we need both
            local content = {}
            for _, name in ipairs(list) do
                content[name] = true
            end
            local pokemon_master = LIST_CODES[k].master ~= nil and content[LIST_CODES[k].master] -- master is for all goals in table or pokemon_master string
            for name, codes in pairs(LIST_CODES[k].values or {}) do -- only two stages
                local stage = (pokemon_master or content[name]) and 1 or 0
                for _, code in ipairs(type(codes) == "table" and codes or { codes }) do
                    Tracker:FindObjectForCode(code).CurrentStage = stage
                end
            end
            local stages = {}
            for name, entry in pairs(LIST_CODES[k].stages or {}) do -- more than two stages, basically just for adjust levels lol
                local code, stage = entry[1], entry[2]
                stages[code] = math.max(stages[code] or 0, content[name] and stage or 0)
            end
            for code, stage in pairs(stages) do
                Tracker:FindObjectForCode(code).CurrentStage = stage
            end
        end
    end
end

function onClear(slot_data)
    print(string.format("called onClear, slot_data:\n%s", dump_table(slot_data)))
    SLOT_DATA = slot_data
    CUR_INDEX = -1
    LOCAL_ITEMS = {}
    GLOBAL_ITEMS = {}
    CAUGHT = {}
    SEEN = {}
    EVENT_BITS = {}
    MAP_ID = {}
    PLAYER_ID = Archipelago.PlayerNumber or -1
    TEAM_NUMBER = Archipelago.TeamNumber or 0

    -- reset items
    for _, v in pairs(ITEM_MAPPING) do
        if v[1] and v[2] then
            for _, code in ipairs(v[1]) do
                resetItem(code, v[2])
            end
        end
    end

    resetLocations()

    REGION_ENCOUNTERS = slot_data.encounter_by_method
    -- Static Encounters etc. added manually
    local newEncounters = {
        Magikarp_Gift = 129,
        Zorua_Gift = 570,
        Larvesta_Egg = 636,
        Omanyte_Fossil = 138,
        Kabuto_Fossil = 140,
        Aerodactyl_Fossil = 142,
        Lileep_Fossil = 345,
        Anorith_Fossil = 347,
        Cranidos_Fossil = 408,
        Shieldon_Fossil = 410,
        Tirtouga_Fossil = 564,
        Archen_Fossil = 566,
        Munchlax_Trade = 446,
        Rotom_Trade = 479,
        Cottonee_Trade = 546,
        Petilil_Trade = 548,
        Basculin_Trade = slot_data.options.version == "white" and 550 + (1 << 11) or 550,
        Emolga_Trade = 587,
        Foongus_Trap6 = 590,
        Foongus_Trap10 = 590,
        Amoonguss_Trap = 591,
        Victini_Static = 494,
        Musharna_Static = 518,
        Darmanitan_Static = 555,
        Zoroark_Static = 571,
        Volcarona_Static = 637,
        Cobalion_Static = 638,
        Terrakion_Static = 639,
        Virizion_Static = 640,
        Reshiram_Static = 643,
        Zekrom_Static = 644,
        Landorus_Static = 645,
        Kyurem_Static = 646,
        Tornadus_Roamer = 641,
        Thundurus_Roamer = 642,
        Dwebble_R13 = 557,
        Dwebble_WC = 557,
        Dwebble_CC = 557,
        Dwebble_DY = 557
    }

    for name, pokemon_id in pairs(newEncounters) do
        REGION_ENCOUNTERS[name] = { pokemon_id }
    end
    --print(dump_table(REGION_ENCOUNTERS))

    -- so we can access the mapping later
    POKEMON_TO_LOCATIONS = {}
    for location, pokemon_list in pairs(REGION_ENCOUNTERS) do
        for _, pokemon_id in pairs(pokemon_list) do
            if POKEMON_TO_LOCATIONS[pokemon_id] == nil then
                POKEMON_TO_LOCATIONS[pokemon_id] = {}
            end
            table.insert(POKEMON_TO_LOCATIONS[pokemon_id], location)
        end
    end

    -- This sets each Encounter location to however many unique encounters there are in it
    for region_key, location in pairs(ENCOUNTER_MAPPING) do
        local object = Tracker:FindObjectForCode(location)
        object.AvailableChestCount = #REGION_ENCOUNTERS[region_key]
    end

    for bucket = 0, 20 do
        LEVEL_REGIONS[bucket] = {}
    end
    for region, level in pairs(slot_data.level_by_region) do
        local code = ENCOUNTER_MAPPING[region] or "@" .. region .. " Access"
        if Tracker:FindObjectForCode(code) then
            table.insert(LEVEL_REGIONS[level // 5], code)
        end
    end

    -- Main Slot Data Processing
    applyCodes(slot_data) -- top level
    applyCodes(slot_data.options)  -- nested

    -- Weird Slot Data Processing
    local hm_with_badges_found = false
    local add_rock_smash_found = false
    local add_ss_ticket_found = false
    local add_pass_found = false
    local extra_cut_trees_found = false
    local move_strength_boulders_found = false

    -- defaults for missing keys (extra logic)
    if slot_data.starting_town == nil then
        Tracker:FindObjectForCode("starting_town").CurrentStage = 0
    end
    if slot_data.dark_areas == nil then
        for area, code in pairs(LIST_CODES.dark_areas.values) do
            Tracker:FindObjectForCode(code).CurrentStage = DEFAULT_DARK_AREAS[area] and 1 or 0
        end
    end

    -- I don't know how to map these differently :D
    for k, v in pairs(slot_data.options) do
        if k == "plugin_options" then
            local extra_logic = v.extra_logic or {}
            if extra_logic.hm_with_badges ~= nil then
                hm_with_badges_found = true
                local cut_requirement = Tracker:FindObjectForCode("hm01cut")
                local surf_requirement = Tracker:FindObjectForCode("hm03surf")
                local strength_requirement = Tracker:FindObjectForCode("hm04strength")
                local waterfall_requirement = Tracker:FindObjectForCode("hm05waterfall")
                local dive_requirement = Tracker:FindObjectForCode("hm06dive")
                local rock_smash_requirement = Tracker:FindObjectForCode("tm94rocksmash")
                if extra_logic.hm_with_badges == true then
                    cut_requirement.CurrentStage = 0
                    surf_requirement.CurrentStage = 0
                    strength_requirement.CurrentStage = 0
                    waterfall_requirement.CurrentStage = 0
                    dive_requirement.CurrentStage = 0
                    rock_smash_requirement.CurrentStage = 0
                else
                    cut_requirement.CurrentStage = 1
                    surf_requirement.CurrentStage = 1
                    strength_requirement.CurrentStage = 1
                    waterfall_requirement.CurrentStage = 1
                    dive_requirement.CurrentStage = 1
                    rock_smash_requirement.CurrentStage = 1
                end
            end
            if extra_logic.add_rock_smash ~= nil or extra_logic.add_rock_smash_musharna ~= nil then
                add_rock_smash_found = true
                local item = Tracker:FindObjectForCode("add_rocksmash")
                if extra_logic.add_rock_smash == true and extra_logic.add_rock_smash_musharna == true then
                    item.CurrentStage = 2
                elseif extra_logic.add_rock_smash == true then
                    item.CurrentStage = 1
                else
                    item.CurrentStage = 0
                end
            end
            if extra_logic.add_ss_ticket ~= nil then
                add_ss_ticket_found = true
                local item = Tracker:FindObjectForCode("add_ssticket")
                item.CurrentStage = extra_logic.add_ss_ticket == true and 1 or 0
            end
            if extra_logic.add_pass ~= nil then
                add_pass_found = true
                local item = Tracker:FindObjectForCode("add_pass")
                item.CurrentStage = extra_logic.add_pass == true and 1 or 0
            end
            if extra_logic.extra_cut_trees ~= nil or extra_logic.extra_cut_trees_kyurem ~= nil then
                extra_cut_trees_found = true
                local item = Tracker:FindObjectForCode("ex_cut_trees")
                if extra_logic.extra_cut_trees == true and extra_logic.extra_cut_trees_kyurem == true then
                    item.CurrentStage = 2
                elseif extra_logic.extra_cut_trees == true then
                    item.CurrentStage = 1
                else
                    item.CurrentStage = 0
                end
            end
            if extra_logic.move_strength_boulders ~= nil or extra_logic.move_strength_boulders_vi_road ~= nil then
                move_strength_boulders_found = true
                local item = Tracker:FindObjectForCode("mo_strength_boulders")
                if extra_logic.move_strength_boulders == true and extra_logic.move_strength_boulders_vi_road == true then
                    item.CurrentStage = 2
                elseif extra_logic.move_strength_boulders == true then
                    item.CurrentStage = 1
                else
                    item.CurrentStage = 0
                end
            end
        elseif k == "dexsanity" then
            Tracker:FindObjectForCode("dexsanity").AcquiredCount = v
        elseif k == "seensanity" then
            Tracker:FindObjectForCode("seensanity").AcquiredCount = v
        elseif k == "shinysanity" then
            Tracker:FindObjectForCode("shinysanity").AcquiredCount = v
        elseif k == "formsanity" then
            Tracker:FindObjectForCode("formsanity").AcquiredCount = v
        elseif k == "shinyformsanity" then
            Tracker:FindObjectForCode("shinyformsanity").AcquiredCount = v
        elseif k == "all_pokemon_seen" then
            Tracker:FindObjectForCode("all_pokemon_seen").Active = (v == 1)
        end
    end

    local dexsanity = Tracker:FindObjectForCode("dexsanity").AcquiredCount
    local seensanity = Tracker:FindObjectForCode("seensanity").AcquiredCount
    local shinysanity = Tracker:FindObjectForCode("shinysanity").AcquiredCount
    local formsanity = Tracker:FindObjectForCode("formsanity").AcquiredCount
    local shinyformsanity = Tracker:FindObjectForCode("shinyformsanity").AcquiredCount
    if dexsanity > 0 or seensanity > 0 or shinysanity > 0 or formsanity > 0 or shinyformsanity > 0 then
        Tracker:FindObjectForCode("location_visibility").CurrentStage = 1
    else
        Tracker:FindObjectForCode("location_visibility").CurrentStage = 0
    end

    if not hm_with_badges_found then
        Tracker:FindObjectForCode("hm01cut").CurrentStage = 1
        Tracker:FindObjectForCode("hm03surf").CurrentStage = 1
        Tracker:FindObjectForCode("hm04strength").CurrentStage = 1
        Tracker:FindObjectForCode("hm05waterfall").CurrentStage = 1
        Tracker:FindObjectForCode("hm06dive").CurrentStage = 1
        Tracker:FindObjectForCode("tm94rocksmash").CurrentStage = 1
    end
    if not add_rock_smash_found then
        Tracker:FindObjectForCode("add_rocksmash").CurrentStage = 0
    end
    if not add_ss_ticket_found then
        Tracker:FindObjectForCode("add_ssticket").CurrentStage = 0
    end
    if not add_pass_found then
        Tracker:FindObjectForCode("add_pass").CurrentStage = 0
    end
    if not extra_cut_trees_found then
        Tracker:FindObjectForCode("ex_cut_trees").CurrentStage = 0
    end
    if not move_strength_boulders_found then
        Tracker:FindObjectForCode("mo_strength_boulders").CurrentStage = 0
    end

    -- pokémon sanities processing
    local dexsanity_numbers = slot_data["all_dexsanity_numbers"] or {} -- new key in 0.4.0, breaks compat with previous versions

    -- dexsanity variants that use dex IDs
    for _, sanity in ipairs({"dexsanity", "seensanity", "shinysanity"}) do
        local active = {}
        for _, pokeID in ipairs(dexsanity_numbers[sanity] or {}) do
            active[pokeID] = true
        end
        for i = 1, 649 do
            SANITY_VISIBLE[sanity][tostring(i)] = active[i] or false
        end
    end

    -- dexsanity variants that use flag IDs
    for _, sanity in ipairs({"formsanity", "shinyformsanity"}) do
        local active = {}
        for _, flagID in ipairs(dexsanity_numbers[sanity] or {}) do
            active[flagID] = true
        end
        for flagID, formID in pairs(FORM_FLAG_MAPPING) do
            SANITY_VISIBLE[sanity][formID] = active[flagID] or false
        end
    end

    -- Datastorage Watches
    if PLAYER_ID>-1 then
        updateEvents(0)

        local suffix = TEAM_NUMBER .. "_" .. PLAYER_ID
        local function makeID(s) return "pokemon_bw_" .. s .. suffix end

        IDs = {
            EVENT      = makeID("events_"),
            CAUGHT     = makeID("caught_"),
            SEEN       = makeID("seen_"),
            HINT       = "_read_hints_" .. suffix,
            WILD_IDS   = makeID("wild_ids_"),
            SLOT_UNLOCK= makeID("tracker_slots_enabled_"),
            VERSION    = makeID("game_version_"),
        }
        for _, id in pairs(IDs) do
            Archipelago:SetNotify({id})
            Archipelago:Get({id})
        end
    end
end

function forSlot(value)
    return value[tostring(getDigits("slotdigit_1", "slotdigit_2", "slotdigit_3"))]
end

function updateSlot()
    updateEvents(forSlot(EVENT_BITS) or 0)
end

function toggleSlots(value)
    if tonumber(value) == 1 then
        Tracker:AddLayouts("layouts/quick_settings_slottrack.json")
    else
        Tracker:AddLayouts("layouts/quick_settings.json")
        Tracker:FindObjectForCode("slotdigit_1").CurrentStage = 0
        Tracker:FindObjectForCode("slotdigit_2").CurrentStage = 0
        Tracker:FindObjectForCode("slotdigit_3").CurrentStage = 0
    end
end

function resetItem(code, type)
    if AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
        print(string.format("onClear: clearing item %s of type %s", code, type))
    end
    local obj = Tracker:FindObjectForCode(code)
    if obj then
        if type == "toggle" then
            obj.Active = false
        elseif type == "progressive" then
            obj.CurrentStage = 0
            obj.Active = false
        elseif type == "consumable" then
            obj.AcquiredCount = 0
        elseif type == "flash_tm" then
            obj.AcquiredCount = 0
            Tracker:FindObjectForCode("tm70flash").Active = false
        elseif type == "rock_smash_tm" then
            obj.AcquiredCount = 0
            Tracker:FindObjectForCode("tm94rocksmash").Active = false
        elseif AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
            print(string.format("onClear: unknown item type %s for code %s", v[2], code))
        end
    elseif AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
        print(string.format("onClear: could not find object for code %s", code))
    end
end

-- called when an item gets collected
function onItem(index, item_id, item_name, player_number)
    if AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
        print(string.format("called onItem: %s, %s, %s, %s, %s", index, item_id, item_name, player_number, CUR_INDEX))
    end
    if not AUTOTRACKER_ENABLE_ITEM_TRACKING then
        return
    end
    if index <= CUR_INDEX then
        return
    end
    CUR_INDEX = index;
    local v = ITEM_MAPPING[item_id]
    if not v then
        if AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
            print(string.format("onItem: could not find item mapping for id %s", item_id))
        end
        return
    end
    if not v[1] then
        return
    end
    for _, code in ipairs(v[1]) do
        if AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
            print(string.format("onItem: code: %s, type %s", code, v[2]))
        end
        local obj = Tracker:FindObjectForCode(code)
        if obj then
            if v[2] == "toggle" then
                obj.Active = true
            elseif v[2] == "progressive" then
                if obj.Active then
                    obj.CurrentStage = obj.CurrentStage + 1
                else
                    obj.Active = true
                end
            elseif v[2] == "consumable" then
                obj.AcquiredCount = obj.AcquiredCount + obj.Increment
            elseif v[2] == "flash_tm" then
                obj.AcquiredCount = obj.AcquiredCount + obj.Increment
                Tracker:FindObjectForCode("tm70flash").Active = true
            elseif v[2] == "rock_smash_tm" then
                obj.AcquiredCount = obj.AcquiredCount + obj.Increment
                Tracker:FindObjectForCode("tm94rocksmash").Active = true
            elseif AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
                print(string.format("onItem: unknown item type %s for code %s", v[2], code))
            end
        elseif AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
            print(string.format("onItem: could not find object for code %s", code))
        end
    end
end

function resetLocations()
    for id, value in pairs(LOCATION_MAPPING) do
        for _, code in pairs(value) do
            local object = Tracker:FindObjectForCode(code)
            if object then
                if code:sub(1, 1) == "@" then
                    object.AvailableChestCount = object.ChestCount
                    object.Highlight = 0
                else
                    object.CurrentStage = 0
                end
            end
        end
    end
end

---- we use this for hint tracking
CLEARED_LOCATIONS = {}

-- called when a location gets cleared
function onLocation(location_id, location_name)
    local value = LOCATION_MAPPING[location_id]
    if not value then
        return
    end
    for _, code in pairs(value) do
        local object = Tracker:FindObjectForCode(code)
        if object then
            if code:sub(1, 1) == "@" then
                object.AvailableChestCount = object.AvailableChestCount - 1
                local current_total = CLEARED_LOCATIONS[code] or 0
                CLEARED_LOCATIONS[code] = current_total + 1
            elseif object.Type == "progressive" then
                object.CurrentStage = object.CurrentStage + 1
            else
                object.Active = true
            end
        elseif AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
            print(string.format("onLocation: could not find object for code %s", code))
        end
    end
end

function onNotify(key, value, old_value)
    if IDs == nil then
        return
    end

    if key == IDs.SLOT_UNLOCK then
        toggleSlots(value)
        return
    end

    if key == IDs.VERSION then
        local version = tonumber(value)
        if SLOT_DATA.options.version == "dynamic" and (version == 0 or version == 1) then
            Tracker:FindObjectForCode("game_version").CurrentStage = version + 2 -- dynamic_black = 0, dynamic_white = 1
        end
        return
    end

    if value ~= nil and value ~= 0 then
        if key == IDs.EVENT then
            EVENT_BITS = value
            updateEvents(forSlot(value) or 0)
        elseif key == IDs.CAUGHT then
            CAUGHT = value
            updateCaught()
        elseif key == IDs.SEEN then
            print(dump_table(value))
            SEEN = value
            updateSeen()
        elseif key == IDs.HINT then
            SAVED_HINTS = value
            updateHints()
            updatePokemon()
        elseif key == IDs.WILD_IDS and old_value ~= nil then
            updateWildBattle(forSlot(value), forSlot(old_value))
        end
    end
end

function updateEvents(value)
    if value ~= nil then
        for i, code in ipairs(FLAG_EVENT_CODES) do
            local bit = (value >> (i - 1)) & 1
            Tracker:FindObjectForCode(code).Active = (bit == 1)
        end
        local opelucid_gym = has("defeatopelucidgym")
        Tracker:FindObjectForCode("defeatdrayden").Active = opelucid_gym
        Tracker:FindObjectForCode("defeatiris").Active = opelucid_gym
        local box_legendary = has("catchreshiramzekrom")
        Tracker:FindObjectForCode("catchreshiram").Active = box_legendary
        Tracker:FindObjectForCode("catchzekrom").Active = box_legendary
    end
end

function updateSeen()
    -- count species, not forms
    local seen_dex = {}
    local seen_count = 0
    for _, pokemon_id in ipairs(SEEN) do
        local dex_number = pokemon_id & 0x7FF
        if not seen_dex[dex_number] then
            seen_dex[dex_number] = true
            seen_count = seen_count + 1
        end
    end
    Tracker:FindObjectForCode("seen_pokemon").AcquiredCount = seen_count
    updatePokemon()
end

function updateCaught()
    for i = 1, 649 do
        if table_contains(CAUGHT, i) then
            Tracker:FindObjectForCode("caught_"..i).Active = true
        else
            Tracker:FindObjectForCode("caught_"..i).Active = false
        end
    end
    updatePokemon()
end

function updateWildBattle(value, old_value)
    if value == nil or Tracker:FindObjectForCode("dexsanity").AcquiredCount == 0 then
        return
    end
    if old_value ~= nil and value[1] == old_value[1] and value[2] == old_value[2] then
        return
    end

    print(dump_table(value))

    -- wild IDs include the form
    local id1 = value[1] & 0x7FF
    local id2 = value[2] & 0x7FF

    local check1 = false
    if id1 ~= 0 then
        local visibility1 = SANITY_VISIBLE.dexsanity[tostring(id1)]
        local sent1 = Tracker:FindObjectForCode(LOCATION_MAPPING[600000 + id1][1]).AvailableChestCount == 0
        check1 = visibility1 and not sent1
    end

    local check2 = false
    if id2 ~= 0 then
        local visibility2 = SANITY_VISIBLE.dexsanity[tostring(id2)]
        local sent2 = Tracker:FindObjectForCode(LOCATION_MAPPING[600000 + id2][1]).AvailableChestCount == 0
        check2 = visibility2 and not sent2
    end

    if check1 and check2 then
        Tracker:UiHint("ActivateTab", "Others")
        Tracker:UiHint("ActivateTab", " ")
        Tracker:UiHint("ActivateTab", "Double Dexsanity")
    elseif check1 and id2 == 0 then
        Tracker:UiHint("ActivateTab", "Others")
        Tracker:UiHint("ActivateTab", " ")
        Tracker:UiHint("ActivateTab", "Single Dexsanity")
    elseif check1 then
        Tracker:UiHint("ActivateTab", "Others")
        Tracker:UiHint("ActivateTab", " ")
        Tracker:UiHint("ActivateTab", "Right Dexsanity")
    elseif check2 then
        Tracker:UiHint("ActivateTab", "Others")
        Tracker:UiHint("ActivateTab", " ")
        Tracker:UiHint("ActivateTab", "Left Dexsanity")
    else
        onMap(CACHED_MAP)
    end
end

function updatePokemon()
    CAUGHT = CAUGHT or {}
    SEEN = SEEN or {}

    if has("encounter_tracking_off") then
        return
    end

    local regionObjects = {}
    local baseCounts = {}
    local pendingDecrements = {}

    for region_key, location in pairs(ENCOUNTER_MAPPING) do
        regionObjects[region_key] = Tracker:FindObjectForCode(location)
        baseCounts[region_key] = #REGION_ENCOUNTERS[region_key]
        pendingDecrements[region_key] = 0
    end

    for pokemon_id, locations in pairs(POKEMON_TO_LOCATIONS) do
        local dex_number = pokemon_id & 0x7FF
        local dexVisibilityCode = SANITY_VISIBLE.dexsanity[tostring(dex_number)]
        local dexSentCode = Tracker:FindObjectForCode(LOCATION_MAPPING[600000 + dex_number][1]).AvailableChestCount == 0

        local is_caught = table_contains(CAUGHT, dex_number)
        local is_seen = false

        if has("all_pokemon_seen") then
            is_seen = true
        else
            is_seen = table_contains(SEEN, pokemon_id)
        end

        local should_decrement = false
        if is_caught then
            should_decrement = true
        elseif has("encounter_tracking_minimal") and (dexSentCode or not dexVisibilityCode) then
            should_decrement = true
        elseif has("encounter_tracking_seen") and not dexVisibilityCode and is_seen then
            should_decrement = true
        end

        if should_decrement == false then
            if has("hint_tracking_on_plus") and SAVED_HINTS ~= nil then
                local padded_dex_number = 600000 + dex_number
                for _, hint in pairs(SAVED_HINTS) do
                    if hint.finding_player == PLAYER_ID and hint.found == false then
                        if padded_dex_number == hint.location then
                            local level = 0
                            if hint.status == 0 then
                                level = HIGHLIGHT_LEVEL[100 + hint.item_flags]
                            else
                                level = HIGHLIGHT_LEVEL[hint.status]
                            end
                            if level ~= Highlight.Priority then
                                should_decrement = true
                                break
                            end
                        end
                    end
                    if should_decrement then break end
                end
            end
        end

        if should_decrement then
            for _, location in pairs(locations) do
                local object_name = ENCOUNTER_MAPPING[location]
                if object_name ~= nil then
                    local object = Tracker:FindObjectForCode(object_name)
                    if object then
                        pendingDecrements[location] = pendingDecrements[location] + 1
                    end
                end
            end
        end
    end
    for region_key, object in pairs(regionObjects) do
        object.AvailableChestCount = baseCounts[region_key] - pendingDecrements[region_key]
    end

    for _, location in pairs(ENCOUNTER_MAPPING) do
        if location and location:sub(1, 1) == "@" then
            local obj = Tracker:FindObjectForCode(location)
            if obj and obj.AvailableChestCount == 0 then
                obj.Highlight = 0
            end
        end
    end
end

-- Auto-tabbing
function updateMap()
    local map_id = forSlot(MAP_ID) or 0
    if has("automap_on") then
        local tabs = MAP_MAPPING[map_id]
        if tabs then
            for _, tab in ipairs(tabs) do
                Tracker:UiHint("ActivateTab", tab)
            end
        end
    end
end

CACHED_MAP = nil

function onMap(mapBounce)
    if not (has("automap_on") and mapBounce and mapBounce.data) then
        return
    end

    CACHED_MAP = mapBounce
    local mapID = mapBounce.data.mapNumber

    -- Safe table checks in case split maps aren't defined in map_mapping.lua
    local xz_split = MAP_SPLIT_MAPPING and MAP_SPLIT_MAPPING[mapID]

    if xz_split then
        local matrixX = mapBounce.data.matrixX
        local matrixZ = mapBounce.data.matrixZ
        
        local tabs = xz_split[matrixX] and xz_split[matrixX][matrixZ]
        if tabs then
            for _, tab in ipairs(tabs) do
                Tracker:UiHint("ActivateTab", tab)
            end
        end

    elseif MAP_MAPPING and MAP_MAPPING[mapID] then    
        local tabs = MAP_MAPPING[mapID]
        if tabs then
            for _, tab in ipairs(tabs) do
                Tracker:UiHint("ActivateTab", tab)
            end
        end
    else
        print("No Mapping found for:")
        print(dump_table(mapBounce))
    end
end

function toggleHints()
    if has("hint_tracking_off") then
        updatePokemon()
        resetHints()
    elseif has("hint_tracking_on") then
        resetHints()
        updateHints()
        updatePokemon()
    elseif has("hint_tracking_on_plus") then
        updateHints()
        updatePokemon()
    end
end

function resetHints()
    CLEARED_HINTS = {}
    for _, hint in ipairs(SAVED_HINTS or {}) do
        if hint.finding_player == PLAYER_ID then
            local mapped = LOCATION_MAPPING[hint.location]
            local locations = (type(mapped) == "table") and mapped or { mapped }

            for _, location in ipairs(locations) do
                -- Only sections (items don't support Highlight)
                if location:sub(1, 1) == "@" then
                    local obj = Tracker:FindObjectForCode(location)
                    local final_value = obj.ChestCount
                    local cleared = CLEARED_LOCATIONS[location] or 0
                    final_value = final_value - cleared
                    obj.AvailableChestCount = final_value
                    obj.Highlight = 0
                end
            end
        end
    end

    for _, location in pairs(ENCOUNTER_MAPPING) do
        if location and location:sub(1, 1) == "@" then
            local obj = Tracker:FindObjectForCode(location)
            obj.Highlight = 0
        end
    end
end

CLEARED_HINTS = {}
function updateHints()
    if not Highlight then return end
    if has("hint_tracking_off") then return end

    CLEARED_HINTS = {}

    for _, locations in pairs(LOCATION_MAPPING) do
        for _, location in pairs(locations) do
            if location:sub(1, 1) == "@" then
                local obj = Tracker:FindObjectForCode(location)
                obj.Highlight = 0
            end
        end
    end
    for _, location in pairs(ENCOUNTER_MAPPING) do
        if location:sub(1, 1) == "@" then
            local obj = Tracker:FindObjectForCode(location)
            obj.Highlight = 0
        end
    end

    local tracking_plus = has("hint_tracking_on_plus")

    ---- We are leaving this here for now to test this later on: https://discord.com/channels/937157230963339364/1487592945703063562
    --if has("keyitem_priority_true") then
    --    for _, location in ipairs(PRIORITY_LOCATIONS) do
    --        loc = Tracker:FindObjectForCode(location)
    --        if loc.AvailableChestCount == 0 then
    --            loc.Highlight = 0
    --        else
    --            loc.Highlight = 3
    --        end
    --    end
    --else
    --
    --    for _, location in ipairs(PRIORITY_LOCATIONS) do
    --        Tracker:FindObjectForCode(location).Highlight = 0
    --    end
    --end

    for _, hint in ipairs(SAVED_HINTS) do
        if hint.finding_player == PLAYER_ID then
            local mapped = LOCATION_MAPPING[hint.location]
            local incoming_val = 0

            if hint.status == 0 then
                incoming_val = HIGHLIGHT_LEVEL[100 + hint.item_flags]
            else
                incoming_val = HIGHLIGHT_LEVEL[hint.status]
            end

            -- Special handling for Pokémon locations (600001–600649)
            if hint.location >= 600001 and hint.location <= 600649 then
                local dex_number = hint.location - 600000

                -- any form counts for dexsanity
                for pokemon_id, poke_locations in pairs(POKEMON_TO_LOCATIONS) do
                    if (pokemon_id & 0x7FF) == dex_number then
                        for _, encounter_key in pairs(poke_locations) do
                            local mapped_location = ENCOUNTER_MAPPING[encounter_key]
                            if mapped_location and mapped_location:sub(1, 1) == "@" then
                                local obj = Tracker:FindObjectForCode(mapped_location)

                                if tracking_plus then
                                    if hint.found == false then
                                        if incoming_val == Highlight.Priority then
                                            obj.Highlight = incoming_val
                                        end
                                    end
                                else
                                    local current_val = obj.Highlight
                                    if current_val == nil or HIGHLIGHT_PRIORITY[incoming_val] < HIGHLIGHT_PRIORITY[current_val] then
                                        obj.Highlight = incoming_val
                                    end
                                end
                            end
                        end
                    end
                end

                goto continue_hint
            end

            local locations = (type(mapped) == "table") and mapped or { mapped }

            for _, location in ipairs(locations) do
                if location:sub(1, 1) == "@" then
                    local obj = Tracker:FindObjectForCode(location)

                    if tracking_plus then
                        if hint.found == false then
                            if incoming_val == Highlight.Priority then
                                obj.Highlight = incoming_val
                            else
                                local current_total = CLEARED_HINTS[location] or 0
                                CLEARED_HINTS[location] = current_total + 1
                            end
                        end
                    else
                        local current_val = obj.Highlight
                        if current_val == nil or HIGHLIGHT_PRIORITY[incoming_val] < HIGHLIGHT_PRIORITY[current_val] then
                            obj.Highlight = incoming_val
                        end
                    end
                end
            end

            ::continue_hint::
        end
    end

    if tracking_plus then
        for location, count in pairs(CLEARED_HINTS) do
            local obj = Tracker:FindObjectForCode(location)
            local cleared = CLEARED_LOCATIONS[location] or 0
            obj.AvailableChestCount = obj.ChestCount - count - cleared
            if obj.AvailableChestCount == 0 then
                obj.Highlight = 0
            end
        end
    end
end

-- add AP callbacks
Archipelago:AddClearHandler("clear handler", onClear)
Archipelago:AddItemHandler("item handler", onItem)
Archipelago:AddLocationHandler("location handler", onLocation)
Archipelago:AddSetReplyHandler("notify handler", onNotify)
Archipelago:AddRetrievedHandler("notify launch handler", onNotify)
Archipelago:AddBouncedHandler("map bounce handler", onMap)